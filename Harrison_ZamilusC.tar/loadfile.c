//Harrison Zamilus

#include <stdio.h>
#include <string.h>

extern void putInMemory(int segment, int offset, char value);
extern void launchProgram(int segment);

void readFile(const char* filename, char* buffer) {
    FILE* file = fopen(filename, "rb");
    if (file == NULL) {
        printf("Error opening file: %s\n", filename);
        return;
    }

    fread(buffer, 1, 1024, file);
    fclose(file);
}

void terminate() {
    
    while (1) {
        
    }
}

void executeProgram(char* name) {
    char buffer[1024]; 
    int segment = 0x2000;


    for (int i = 0; i < 1024; ++i) {
        putInMemory(segment, i, buffer[i]);
    }

    launchProgram(segment);
}

void interrupt21h(int ax, char* bx) {
    if (ax == 4) {
        executeProgram(bx);
    } else if (ax == 5) {
        // Interrupt 0x21 call to terminate the program
        terminate();
    } else {
        // Handles other interrupt 0x21 calls as needed
      
    }
}

int main() {
    interrupt21h(4, "filename");

    // The program will never return from executeProgram

    return 0;
}
