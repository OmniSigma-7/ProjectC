
main ()

{ 

	syscall(0, "tstpr1 is working1\r\n")
        while(1);

}
